#!/bin/bash

cmake ./
